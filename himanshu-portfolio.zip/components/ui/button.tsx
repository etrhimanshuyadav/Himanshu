
export function Button({ children, ...props }: any) {
  return (
    <button {...props} className="bg-transparent border rounded px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700">
      {children}
    </button>
  );
}
