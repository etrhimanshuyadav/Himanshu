
export function Card({ children }: any) {
  return <div className="bg-white dark:bg-gray-900 p-6 rounded-2xl shadow-md">{children}</div>;
}
export function CardContent({ children }: any) {
  return <div className="text-base">{children}</div>;
}
